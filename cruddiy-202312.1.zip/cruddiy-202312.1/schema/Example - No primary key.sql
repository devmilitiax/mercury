CREATE TABLE `example_no_primary_key` (
  `text` text NOT NULL,
  `varchar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;