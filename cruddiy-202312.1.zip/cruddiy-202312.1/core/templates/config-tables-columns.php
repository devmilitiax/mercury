<?php

$tables_and_columns_names = {{TABLE_NAMES}};

?>